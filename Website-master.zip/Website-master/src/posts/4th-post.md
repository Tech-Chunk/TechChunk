---
title: Post 4
description: First post.
date: '2020-4-30'
categories:
  - VR
  - Headset
published: true
author: Charlie
background: 'headset.jpeg'
---

Apple is working on a new vr headset. The headset is expected to be released in 2023.