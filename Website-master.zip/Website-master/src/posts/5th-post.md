---
title: post5
description: Apple Release VR Headset.
date: '2019-4-30'
categories:
  - VR
  - Headset
published: true
author: Charlie
background: 'headset.jpeg'
---

Apple is working on a new vr headset. The headset is expected to be released in 2023.