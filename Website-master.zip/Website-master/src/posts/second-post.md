---
title: Second
description: Second post.
date: '2022-4-16'
categories:
  - sveltekit
  - svelte
author: cloudy
published: true
background: '/headset.jpeg'
---

## Svelte

Media inside the **static** folder is served from `/`.

![Svelte](favicon.png)
