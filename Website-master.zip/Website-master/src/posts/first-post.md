---
title: Post 1
description: First post.
date: '2023-4-18'
categories:
  - sveltekit
  - svelte
published: true
author: cloudy
background: '/headset.jpeg'
---

## Markdown

Hey friends! 👋
