<script>

    import styles from "./styles.css";

</script>


<div class="main">


    <div class="grid">
        <div class="header">
            <h1>My Profile</h1>

            <div class="wrapper">


                <h1>Name</h1>
                <h1>@username</h1>

                <div class="buttons"></div>

                    <button>Settings</button>
                    <button>Edit Profile</button>

                    <button class="donatorbutton">Donator</button>
                    

                </div>

                <div class="recently liked">
        
                    <div class="likedpost">
                    </div>
                    <div class="likedpost">
                    </div>
                    <div class="likedpost">
                    </div>
                    
                    
                
                </div>

            </div>



    </div>



</div>