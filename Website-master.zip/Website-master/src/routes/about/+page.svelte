<svelte:head>
	<title>About</title>
	<meta name="description" content="About this app" />
</svelte:head>

<div class="text-column">
	<h1>About</h1>
	<p>We are an apple news site, dedicated to finding the latest apple news and leaks on the internet</p>
</div>
