import * as universal from "../../../../src/routes/posts/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/posts/+page.svelte";