import * as universal from "../../../../src/routes/about/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/about/+page.svelte";