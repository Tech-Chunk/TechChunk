import * as universal from "../../../../src/routes/posts/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/posts/[slug]/+page.svelte";