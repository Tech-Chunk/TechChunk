

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.ee68a87a.js","_app/immutable/chunks/index.b4b62c68.js","_app/immutable/chunks/singletons.f85dc50f.js","_app/immutable/chunks/index.d64fbed3.js"];
export const stylesheets = [];
export const fonts = [];
