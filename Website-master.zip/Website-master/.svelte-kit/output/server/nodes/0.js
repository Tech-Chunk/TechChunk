

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.d08ada02.js","_app/immutable/chunks/index.b4b62c68.js","_app/immutable/chunks/pocketbase.ec0be321.js","_app/immutable/chunks/index.d64fbed3.js","_app/immutable/chunks/forms.36e5f795.js","_app/immutable/chunks/parse.bee59afc.js","_app/immutable/chunks/singletons.f85dc50f.js"];
export const stylesheets = ["_app/immutable/assets/0.484f9e8a.css"];
export const fonts = [];
