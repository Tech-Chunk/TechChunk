function m(t,e="medium",r="en"){return new Intl.DateTimeFormat(r,{dateStyle:e}).format(new Date(t))}export{m as f};
